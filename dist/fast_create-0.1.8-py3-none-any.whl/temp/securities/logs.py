

def SessionLogging (enable: bool = False):
    """
    Function to echo all transaction in database
    """
    return enable

